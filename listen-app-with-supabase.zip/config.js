// ========================================
// Listen.Sound.Reflect.Create - Configuration
// ========================================

// ВАЖНО: Замените эти значения на ваши реальные ключи!
// Для продакшена используйте переменные окружения

const CONFIG = {
    // Supabase Configuration
    SUPABASE: {
        URL: 'https://your-project.supabase.co',
        ANON_KEY: 'your-anon-key-here',
        SERVICE_ROLE_KEY: 'your-service-role-key-here' // Только для серверной части
    },
    
    // Telegram Bot Configuration
    TELEGRAM: {
        BOT_TOKEN: 'your-bot-token-here', // Только для серверной части
        BOT_USERNAME: 'ListenSoundReflectCreateBot',
        WEBAPP_URL: 'https://t.me/ListenSoundReflectCreateBot/LSRC'
    },
    
    // Deployment URLs
    DEPLOYMENT: {
        VERCEL_URL: 'https://your-project.vercel.app',
        DOMAIN: 'your-custom-domain.com' // Если есть
    },
    
    // Audio Configuration
    AUDIO: {
        MAX_FILE_SIZE_MB: 10,
        ALLOWED_FORMATS: ['webm', 'wav', 'mp3', 'm4a'],
        STORAGE_BUCKET: 'audio',
        MAX_DURATION_SECONDS: 300 // 5 минут
    },
    
    // Application Settings
    APP: {
        DEFAULT_LANGUAGE: 'en',
        ENABLE_ANALYTICS: false,
        DEBUG_MODE: false,
        VERSION: '1.0.0'
    },
    
    // Security Settings
    SECURITY: {
        CORS_ORIGINS: [
            'https://your-project.vercel.app',
            'https://t.me'
        ],
        RATE_LIMIT_PER_MINUTE: 60
    },
    
    // Optional: External Services
    EXTERNAL_SERVICES: {
        OPENAI_API_KEY: '', // Для транскрипции аудио
        GOOGLE_CLOUD_API_KEY: '', // Альтернатива для speech-to-text
        ENABLE_TRANSCRIPTION: false
    }
};

// Функция для получения конфигурации с проверкой окружения
function getConfig() {
    // В продакшене можно использовать переменные окружения
    if (typeof process !== 'undefined' && process.env) {
        return {
            ...CONFIG,
            SUPABASE: {
                URL: process.env.SUPABASE_URL || CONFIG.SUPABASE.URL,
                ANON_KEY: process.env.SUPABASE_ANON_KEY || CONFIG.SUPABASE.ANON_KEY,
                SERVICE_ROLE_KEY: process.env.SUPABASE_SERVICE_ROLE_KEY || CONFIG.SUPABASE.SERVICE_ROLE_KEY
            },
            TELEGRAM: {
                BOT_TOKEN: process.env.TELEGRAM_BOT_TOKEN || CONFIG.TELEGRAM.BOT_TOKEN,
                BOT_USERNAME: process.env.TELEGRAM_BOT_USERNAME || CONFIG.TELEGRAM.BOT_USERNAME,
                WEBAPP_URL: process.env.TELEGRAM_WEBAPP_URL || CONFIG.TELEGRAM.WEBAPP_URL
            }
        };
    }
    
    return CONFIG;
}

// Проверка конфигурации
function validateConfig(config = CONFIG) {
    const errors = [];
    
    if (!config.SUPABASE.URL || config.SUPABASE.URL.includes('your-project')) {
        errors.push('SUPABASE_URL не настроен');
    }
    
    if (!config.SUPABASE.ANON_KEY || config.SUPABASE.ANON_KEY.includes('your-anon-key')) {
        errors.push('SUPABASE_ANON_KEY не настроен');
    }
    
    if (!config.DEPLOYMENT.VERCEL_URL || config.DEPLOYMENT.VERCEL_URL.includes('your-project')) {
        errors.push('VERCEL_URL не настроен');
    }
    
    return {
        isValid: errors.length === 0,
        errors
    };
}

// Экспорт для использования в других файлах
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { CONFIG, getConfig, validateConfig };
}

// Для использования в браузере
if (typeof window !== 'undefined') {
    window.APP_CONFIG = CONFIG;
    window.getConfig = getConfig;
    window.validateConfig = validateConfig;
}
